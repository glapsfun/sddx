v5 fixture
