import { expect, test } from "bun:test";
import { health } from "../health";

test("health", () => {
  expect(health()).toEqual({ status: "ok" });
});
