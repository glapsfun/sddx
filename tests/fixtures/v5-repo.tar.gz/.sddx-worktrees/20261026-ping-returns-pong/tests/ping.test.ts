import { expect, test } from "bun:test";
import { ping } from "../ping";

test("ping", () => {
  expect(ping()).toBe("pong");
});
